<?php
//reception des données
if(empty($_POST["nom"])|| empty($_POST["prenom"])|| empty($_POST["pseudo"])|| empty($_POST["mdp"])|| empty($_POST["conf"])|| empty($_POST["type"]))
{
$retour='<a href="ajouter_ut.php?flag=Tous les champs sont obligatoires">Retour</a>';
die ("erreur d'ajouter l'utilisateur: ". $retour);}

$nom=$_POST["nom"];
$prenom=$_POST["prenom"];
$pseudo=$_POST["pseudo"];
$pass=$_POST["mdp"];
$conf=$_POST["conf"];
$type=$_POST["type"];
//verifier le taille du login et mot de passe entre 6 et 32
if (strlen($pseudo)<6 || strlen($pseudo)>32 || strlen($pass)<6 || strlen ($pass)>32 )
{$retour='<a href="ajouter_ut.php?flag=vos param&egrave;tres authantification doivent avoir entre 6 et 32 caract&egrave;res">Retour</a>';
die ("erreur d'ajouter l'utilisateur: ". $retour);}
// verifier que les deux chaines sont identique
if ($pass!=$conf)
{
$retour='<a href="ajouter_ut.php?flag=verifier la saisire du mot de passe.">Retour</a>';
die ("erreur d'ajouter l'utilisateur: ". $retour);}
//verifier qui la pseudo sont unique
$req="SELECT pseudo FROM utilisateur WHERE pseudo='$pseudo';";
//connexion a la base de données
$cnx=mysqli_connect("localhost","root","","bd1");
//arrêt le script en cas d'erreur de conexion au serveur
if (mysqli_connect_errno())
  {
   die ("connexion ipossible au serveur". mysqli_connect_error());
  }


$res=mysqli_query($cnx,$req);
if(!$res) die (" erreur d'executer la requete:  ".mysqli_error($cnx));

if(mysqli_num_rows($res))
{
$retour='<a href="ajouter_ut.php?flag=ce pseudo est pris par un autre utilisateur.">Retour</a>';
die ("erreur d'ajouter l'utilisateur: ". $retour);}

//requete pour ajouter l'utilisateur
$req="INSERT INTO utilisateur (nom_u, prenom_u, pseudo, mdp,type) VALUES ('$nom','$prenom','$pseudo','$pass','$type');";
//executer la requete
$res=mysqli_query($cnx,$req);
if (!$res) die ("erreur d'executer la requete:". mysqli_error($cnx));
else
{$flag=" utilisateur ajouté,vous voulez ajouter un autre";
header("Location:ajouter_ut.php? flag=$flag");
}
?>