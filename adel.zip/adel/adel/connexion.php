<?php
//connexion au serveur
$cnx=mysqli_connect("localhost","root","","bd1");
//arrêt le script en cas d'erreur de conexion au serveur
if(!$cnx) die ("connexion ipossible au serveur");
?>
 